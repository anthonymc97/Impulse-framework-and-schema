function meta:SendHint()
	return
end