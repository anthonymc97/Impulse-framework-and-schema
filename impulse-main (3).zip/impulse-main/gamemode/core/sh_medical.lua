function meta:HasBrokenLegs()
	return self:GetSyncVar(SYNC_BROKENLEGS, false)
end