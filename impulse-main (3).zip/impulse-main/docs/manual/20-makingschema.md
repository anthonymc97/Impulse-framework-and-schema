# Making a schema
lol