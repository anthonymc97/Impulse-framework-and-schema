ENT.Base			= "base_gmodentity" 
ENT.Type			= "anim"
ENT.PrintName		= "Storage Box"
ENT.Author			= "vin"
ENT.Purpose			= ""
ENT.Instructions	= "Press E"
ENT.Category 		= "impulse"

ENT.Spawnable = true
ENT.AdminOnly = true

ENT.HUDName = "Storage box"
ENT.HUDDesc = "Deposit or withdraw items."