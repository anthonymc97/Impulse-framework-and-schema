ENT.Type = "anim"
ENT.Base = "base_anim" 

ENT.Spawnable = false
ENT.AdminSpawnable = false