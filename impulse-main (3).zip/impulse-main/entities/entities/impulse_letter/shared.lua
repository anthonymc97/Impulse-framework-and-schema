ENT.Type = "anim"
ENT.Base = "base_anim" 

ENT.PrintName		= "Letter"
ENT.Author			= "aLoneWitness"
ENT.Contact			= ""
ENT.Purpose			= "A letter you can pour your soul into."
ENT.Information		= "A letter you can pour your soul into."
ENT.Category		= "impulse"

ENT.Spawnable		= false
ENT.AdminSpawnable	= false

ENT.HUDName = "Letter"
ENT.HUDDesc = "A readable letter."