ENT.Base			= "base_gmodentity" 
ENT.Type			= "anim"
ENT.PrintName		= "Storage Box (Public)"
ENT.Author			= "vin"
ENT.Purpose			= ""
ENT.Instructions	= "Press E"
ENT.Category 		= "impulse"

ENT.Spawnable = true
ENT.AdminOnly = true

ENT.HUDName = "Public storage locker"
ENT.HUDDesc = "Deposit or withdraw legal items."