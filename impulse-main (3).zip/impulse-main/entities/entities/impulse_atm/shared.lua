ENT.Base			= "base_gmodentity" 
ENT.Type			= "anim"
ENT.PrintName		= "ATM"
ENT.Author			= "vin, aLoneWitness"
ENT.Purpose			= ""
ENT.Instructions	= "Press E"
ENT.Category 		= "impulse"

ENT.Spawnable = true
ENT.AdminOnly = true

ENT.HUDName = "ATM"
ENT.HUDDesc = "Deposit or withdraw money."