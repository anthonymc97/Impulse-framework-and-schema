DeriveGamemode("impulse")
impulse.Schema.Boot("impulseskeleton")