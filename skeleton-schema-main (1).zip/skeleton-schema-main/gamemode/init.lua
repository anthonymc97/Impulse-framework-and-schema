AddCSLuaFile("cl_init.lua")
DeriveGamemode("impulse")
impulse.Schema.Boot("impulseskeleton")


