impulse.Business.Define("Apple", {
	item = "food_apple",
	price = 42,
	category = "Food and Ingredients",
    teams = {TEAM_CITIZEN}
})
