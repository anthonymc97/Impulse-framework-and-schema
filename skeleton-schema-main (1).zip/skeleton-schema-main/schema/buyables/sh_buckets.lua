impulse.Business.Define("Bucket", {
	item = "item_bucket",
	price = 10,
	category = "BUCKETS!!!!!!!!!!!!!!!!!!!!",
    teams = {TEAM_CITIZEN}
})
