TEAM_MAYOR = impulse.Teams.Define({
	name = "Mayor",
	color = Color(211, 0, 208),
	description = [[Be corrupt]],
	loadout = {"impulse_hands", "weapon_physgun", "gmod_tool"},
	salary = 10000,
	model = "models/player/breen.mdl",
	limit = 1,
	xp = 500,
	cp = true,
    doorGroup = {1, 3}
})