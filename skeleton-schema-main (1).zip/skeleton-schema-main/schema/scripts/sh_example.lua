-- you can put any files in the scripts folder, just prefix them with sv_, sh_ or cl_ to load them in the correct state.
-- you should put vgui in the vgui folder, and hooks in hooks
-- same rules apply to all plugins

print("schema/scripts/sh_example.lua running shared code!")